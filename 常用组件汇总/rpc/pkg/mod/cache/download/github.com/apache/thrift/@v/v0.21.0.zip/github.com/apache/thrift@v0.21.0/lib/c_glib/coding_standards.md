## C Glib Coding Standards

Please follow:
 * [Thrift General Coding Standards](/doc/coding_standards.md)
 * [GNOME C Coding Style](https://help.gnome.org/users/programming-guidelines/stable/c-coding-style.html.en)
