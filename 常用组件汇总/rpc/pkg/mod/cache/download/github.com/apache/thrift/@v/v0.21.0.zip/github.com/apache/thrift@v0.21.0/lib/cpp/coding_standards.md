Please follow [General Coding Standards](/doc/coding_standards.md)

 * see .clang-format in root dir for settings of accepted format
 * clang-format (3.5 or newer) can be used to automaticaly reformat code ('make style' command)
